#!/bin/bash
read -p 'Enter your New API Key: ' newapi
sed -i "s/_apiKey = '.*'/_apiKey = '$newapi'/" /var/saado/mfw/http/Client.php
sed -i "s/_apiKey = '.*'/_apiKey = '$newapi'/" /var/saado/applications/bluemail/assets/server/track.php