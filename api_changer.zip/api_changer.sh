#!/bin/bash
read -p 'Enter your New API Key: ' newapi
sed -i "s/_apiKey = '.*'/_apiKey = '$newapi'/" /var/bluemail/mfw/http/Client.php