#! /bin/bash
cd $(dirname $0)
for line in $(grep -v '^#' /root/alldomains);
 do
  ./firewall.sh $line $1
 done
exit