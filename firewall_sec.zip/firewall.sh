#! /bin/bash
cd $(dirname $0)

dyn_name="$1"
if [[ $2 = "" ]];
 then
  zone="trusted"
 else
  zone="$2"
fi

newip=$(/usr/bin/dig $dyn_name +short | head -1)

function fn_dig_check ()
if [[ $newip == "" ]];
 then
  logger firewall.sh:error:domain not resolved domain=$dyn_name zone=$zone
  exit 2
fi

function fn_in_firewall ()
{
if [[ $(firewall-cmd --get-active-zones) =~ $newip ]];
 then
  if [[ ! $(firewall-cmd --list-sources --zone=$zone) =~ $newip ]];
   then
    logger firewall.sh:error:source conflict domain=$dyn_name zone=$zone ip=$newip
    exit 2
   else 
    exit
  fi
fi
}

function fn_update ()
{
oldip=$(/bin/cat ./ip_of_$dyn_name 2>/dev/null)
if [[ $(firewall-cmd --list-sources --zone=$zone) =~ $oldip ]] && [[ ! $oldip == "" ]];
 then
  firewall-cmd --remove-source=$oldip --zone=$zone
  logger firewall.sh:info:rule changed ip removed domain=$dyn_name zone=$zone oldip=$oldip
  fn_update_action
 else
  fn_update_action
fi
}

function fn_update_action ()
{
  firewall-cmd --add-source=$newip --zone=$zone
  echo $newip > ./ip_of_$dyn_name
  logger firewall.sh:info:rule changed ip added domain=$dyn_name zone=$zone newip=$newip
}

fn_dig_check
fn_in_firewall
fn_update
exit